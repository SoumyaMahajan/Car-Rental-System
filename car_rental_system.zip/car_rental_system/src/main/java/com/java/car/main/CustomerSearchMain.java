package com.java.car.main;

import java.sql.SQLException;
import java.util.Scanner;


import com.java.car.model.Customer;
import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;

public class CustomerSearchMain {


    public static void main(String[] args) {
		int customerID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter CustomerID");
		customerID = sc.nextInt();
		CustomerDao dao = new CustomerDaoImpl();
		try {
			Customer customer = dao.searchByCustomerID(customerID);
			if (customer!= null) {
				System.out.println(customer);
			}else {
				System.out.println("*** Customer Record Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
