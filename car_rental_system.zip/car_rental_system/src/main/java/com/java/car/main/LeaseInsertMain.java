package com.java.car.main;

import java.sql.SQLException;
import java.util.Scanner;


import com.java.car.model.Customer;
import com.java.car.model.Lease;
import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;
import com.java.car.dao.LeaseDao;
import com.java.car.dao.LeaseDaoImpl;

public class LeaseInsertMain {

	 public static void main(String[] args) {
			Lease lease = new Lease();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter LeaseID");
			lease.setLeaseID(sc.nextInt());
			System.out.println("Enter VehicleID ");
			lease.setVehicleID(sc.nextInt());
			System.out.println("Enter CustomerID ");
			lease.setCustomerID(sc.nextInt());
			System.out.println("Enter StartDate ");
			lease.setStartDate(sc.nextInt());
			System.out.println("Enter EndDate ");
			lease.setEndDate(sc.nextInt());
			System.out.println("Enter type ");
			lease.setType(sc.next());
			
			LeaseDao dao = new LeaseDaoImpl();
			try {
				System.out.println(dao.addLeaseDao(lease));
				}
			 catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
