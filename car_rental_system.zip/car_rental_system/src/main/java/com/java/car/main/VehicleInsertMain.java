package com.java.car.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;
import com.java.car.dao.VehicleDao;
import com.java.car.dao.VehicleDaoImpl;
import com.java.car.model.Customer;
import com.java.car.model.Vehicle;

public class VehicleInsertMain {

	public static void main(String[] args) {
		Vehicle vehicle = new Vehicle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter VehicleID");
		vehicle.setVehicleID(sc.nextInt());
		System.out.println("Enter Make");
		vehicle.setMake(sc.next());
		System.out.println("Enter Model");
		vehicle.setModel(sc.next());
		System.out.println("Enter Year");
		vehicle.setYear(sc.nextInt());
		System.out.println("Enter DailyRate");
		vehicle.setDailyRate(sc.nextDouble());
		System.out.println("Enter Status");
		vehicle.setStatus(sc.nextInt());
		System.out.println("Enter PassengerCapacity");
		vehicle.setPassengerCapacity(sc.nextInt());
		System.out.println("Enter EngineCapacity");
		vehicle.setEngineCapacity(sc.nextInt());
		
		
		VehicleDao dao = new VehicleDaoImpl();
		try {
			System.out.println(dao.addVehicleDao(vehicle));
			}
		 catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
