package com.java.car.main;

import java.sql.SQLException;
import java.util.Scanner;


import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;

public class CustomerDeleteMain {

	public static void main(String[] args) {
		int customerID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter CustomerID  ");
		customerID = sc.nextInt();
		CustomerDao dao = new CustomerDaoImpl();
		try {
			System.out.println(dao.deleteCustomerDao(customerID));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
