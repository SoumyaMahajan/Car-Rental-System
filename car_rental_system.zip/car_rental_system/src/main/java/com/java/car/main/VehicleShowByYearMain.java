package com.java.car.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;
import com.java.car.dao.VehicleDao;
import com.java.car.dao.VehicleDaoImpl;
import com.java.car.model.Customer;
import com.java.car.model.Vehicle;

public class VehicleShowByYearMain {

	public static void main(String[] args) {
		int Year;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Year");
		Year = sc.nextInt();
		VehicleDao dao = new VehicleDaoImpl();
		try {
			List<Vehicle> vehicle = dao.showByYear(Year);
			if (vehicle!= null) {
				System.out.println(vehicle);
			}else {
				System.out.println("*** Vehicle Not Found ***");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}