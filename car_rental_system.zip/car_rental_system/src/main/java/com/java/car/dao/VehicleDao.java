package com.java.car.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.car.model.Customer;
import com.java.car.model.Vehicle;


public interface VehicleDao {

	List<Vehicle> showVehicleDao() throws ClassNotFoundException, SQLException;
	List<Vehicle> showByMake(String Make) throws ClassNotFoundException, SQLException;
	List<Vehicle> showByModel(String Model) throws ClassNotFoundException, SQLException;
	List<Vehicle> showByYear(int Year) throws ClassNotFoundException, SQLException;
	List<Vehicle> showByPassengerCapacity(int PassengerCapacity) throws ClassNotFoundException, SQLException;
	String addVehicleDao(Vehicle vehicle) throws ClassNotFoundException, SQLException;
}
