package com.java.car.main;

import java.sql.SQLException;
import java.util.List;


import com.java.car.model.Lease;
import com.java.car.dao.LeaseDao;
import com.java.car.dao.LeaseDaoImpl;

public class LeaseShowMain {


    public static void main(String[] args) {
		LeaseDao dao = new LeaseDaoImpl();
		try {
			List<Lease> leaseList = dao.showLeaseDao();
			for (Lease lease : leaseList) {
				System.out.println(lease);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}