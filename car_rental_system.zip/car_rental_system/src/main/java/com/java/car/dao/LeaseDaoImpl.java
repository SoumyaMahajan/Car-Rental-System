package com.java.car.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.car.model.Customer;
import com.java.car.model.Lease;
import com.java.car.model.Type;
import com.java.car.model.Vehicle;
import com.java.car.util.DBConnUtil;
import com.java.car.util.DBPropertyUtil;



public class LeaseDaoImpl implements LeaseDao {

	Connection connection;
	PreparedStatement pst;
	
	@Override
	public List<Lease> showLeaseDao() throws ClassNotFoundException, SQLException {
		String connStr =com.java.car.util.DBPropertyUtil.connectionString("db");
		connection = com.java.car.util.DBConnUtil.getConnection(connStr);
		String cmd = "select * from Lease";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Lease> leaseList = new ArrayList<Lease>();
		Lease lease = null;
		while(rs.next()) {
			lease = new Lease();
			lease.setLeaseID(rs.getInt("leaseID"));
			lease.setVehicleID(rs.getInt("vehicleID"));
			lease.setCustomerID(rs.getInt("customerID"));
			lease.setStartDate(rs.getInt("startDate"));
//			lease.setType(Type.valueOf(rs.getString("type")));
			leaseList.add(lease);
		}
		return leaseList;
	}
	
	@Override
	public String addLeaseDao(Lease lease) throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "Insert into Lease(leaseID, vehicleID, customerID, startDate, endDate, type ) "
				+ " values(?,?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, lease.getleaseID());
		pst.setInt(2, lease.getVehicleID());
		pst.setInt(3, lease.getCustomerID());
		pst.setInt(4, lease.getStartDate());
		pst.setInt(5, lease.getEndDate());
     	pst.setString(6, lease.getType());
		pst.executeUpdate();
		return "Lease Record Inserted...";
	}
}
