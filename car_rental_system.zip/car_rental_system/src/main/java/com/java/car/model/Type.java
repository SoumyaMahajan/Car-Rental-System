package com.java.car.model;

public enum Type {

	    DAILY, MONTHLY
}
