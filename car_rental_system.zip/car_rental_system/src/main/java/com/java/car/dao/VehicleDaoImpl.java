package com.java.car.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.car.model.Vehicle;
import com.java.car.util.DBConnUtil;
import com.java.car.util.DBPropertyUtil;


public class VehicleDaoImpl implements VehicleDao {

	      Connection connection;
	      PreparedStatement pst;
	      
		@Override
		public List<Vehicle> showVehicleDao() throws ClassNotFoundException, SQLException {
			String connStr = com.java.car.util.DBPropertyUtil.connectionString("db");
			connection = com.java.car.util.DBConnUtil.getConnection(connStr);
			String cmd = "select * from Vehicle";
			pst = connection.prepareStatement(cmd);
			ResultSet rs = pst.executeQuery();
			List<Vehicle> vehicleList = new ArrayList<Vehicle>();
			Vehicle vehicle = null;
			while(rs.next()) {
				vehicle = new Vehicle();
				vehicle.setVehicleID(rs.getInt("VehicleID"));
				vehicle.setMake(rs.getString("Make"));
				vehicle.setModel(rs.getString("Model"));
				vehicle.setYear(rs.getInt("Year"));
				vehicle.setDailyRate(rs.getDouble("DailyRate"));
				vehicle.setStatus(rs.getInt("Status"));
				vehicle.setPassengerCapacity(rs.getInt("PassengerCapacity"));
				vehicle.setEngineCapacity(rs.getInt("EngineCapacity"));
				vehicleList.add(vehicle);
			}
			return vehicleList;
		}

		

		
		@Override
		public List<Vehicle> showByMake(String make) throws ClassNotFoundException, SQLException {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "select * from vehicle where make=?";
			pst = connection.prepareStatement(cmd);
			pst.setString(1,make );
			ResultSet rs = pst.executeQuery();
			List<Vehicle> VehicleList=new ArrayList<Vehicle>();
			Vehicle vehicle=null;
			
			while(rs.next()) {
				vehicle=new Vehicle();
				vehicle.setVehicleID(rs.getInt("vehicleID"));
				vehicle.setMake(rs.getString("make"));
				vehicle.setModel(rs.getString("model"));
				vehicle.setYear(rs.getInt("year"));
				vehicle.setDailyRate(rs.getDouble("dailyRate"));
				vehicle.setStatus(rs.getInt("status"));
				vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
				vehicle.setEngineCapacity(rs.getInt("engineCapacity"));
				VehicleList.add(vehicle);
			}
					return VehicleList;
		}


		@Override
		public List<Vehicle> showByModel(String Model) throws ClassNotFoundException, SQLException {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "select * from vehicle where model=?";
			pst = connection.prepareStatement(cmd);
			pst.setString(1, Model );
			ResultSet rs = pst.executeQuery();
			List<Vehicle> VehicleList=new ArrayList<Vehicle>();
			Vehicle vehicle=null;
			
			while(rs.next()) {
				vehicle=new Vehicle();
				vehicle.setVehicleID(rs.getInt("vehicleID"));
				vehicle.setMake(rs.getString("make"));
				vehicle.setModel(rs.getString("model"));
				vehicle.setYear(rs.getInt("year"));
				vehicle.setDailyRate(rs.getDouble("dailyRate"));
				vehicle.setStatus(rs.getInt("status"));
				vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
				vehicle.setEngineCapacity(rs.getInt("engineCapacity"));
				VehicleList.add(vehicle);
			}
					return VehicleList;
		}




		@Override
		public List<Vehicle> showByYear(int Year) throws ClassNotFoundException, SQLException {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "select * from vehicle where year=?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, Year );
			ResultSet rs = pst.executeQuery();
			List<Vehicle> VehicleList=new ArrayList<Vehicle>();
			Vehicle vehicle=null;
			
			while(rs.next()) {
				vehicle=new Vehicle();
				vehicle.setVehicleID(rs.getInt("vehicleID"));
				vehicle.setMake(rs.getString("make"));
				vehicle.setModel(rs.getString("model"));
				vehicle.setYear(rs.getInt("year"));
				vehicle.setDailyRate(rs.getDouble("dailyRate"));
				vehicle.setStatus(rs.getInt("status"));
				vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
				vehicle.setEngineCapacity(rs.getInt("engineCapacity"));
				VehicleList.add(vehicle);
			}
					return VehicleList;
		}




		@Override
		public List<Vehicle> showByPassengerCapacity(int PassengerCapacity)
				throws ClassNotFoundException, SQLException {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "select * from vehicle where PassengerCapacity=?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, PassengerCapacity );
			ResultSet rs = pst.executeQuery();
			List<Vehicle> VehicleList=new ArrayList<Vehicle>();
			Vehicle vehicle=null;
			
			while(rs.next()) {
				vehicle=new Vehicle();
				vehicle.setVehicleID(rs.getInt("vehicleID"));
				vehicle.setMake(rs.getString("make"));
				vehicle.setModel(rs.getString("model"));
				vehicle.setYear(rs.getInt("year"));
				vehicle.setDailyRate(rs.getDouble("dailyRate"));
				vehicle.setStatus(rs.getInt("status"));
				vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
				vehicle.setEngineCapacity(rs.getInt("engineCapacity"));
				VehicleList.add(vehicle);
			}
					return VehicleList;
		}
		
		
		@Override
		public String addVehicleDao(Vehicle vehicle) throws ClassNotFoundException, SQLException {
			String connStr =DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "Insert into Vehicle(VehicleID, Make, Model, Year, DailyRate, Status, PassengerCapacity, EngineCapacity) "
					+ " values(?,?,?,?,?,?,?,?)";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, vehicle.getVehicleID());
			pst.setString(2, vehicle.getMake());
			pst.setString(3, vehicle.getModel());
			pst.setInt(4, vehicle.getYear());
			pst.setDouble(5, vehicle.getDailyRate());
			pst.setInt(6, vehicle.getStatus());
			pst.setInt(7, vehicle.getPassengerCapacity());
			pst.setInt(8, vehicle.getEngineCapacity());
			pst.executeUpdate();
			return "Vehicle Record Inserted...";
		}

		}


		
		
		
		

