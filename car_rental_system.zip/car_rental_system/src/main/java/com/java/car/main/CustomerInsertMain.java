package com.java.car.main;

import java.sql.SQLException;
import java.util.Scanner;


import com.java.car.model.Customer;
import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;

public class CustomerInsertMain {

	 public static void main(String[] args) {
			Customer customer = new Customer();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter CustomerID");
			customer.setCustomerID(sc.nextInt());
			System.out.println("Enter Customer FirstName ");
			customer.setFirstName(sc.next());
			System.out.println("Enter Customer LastName ");
			customer.setLastName(sc.next());
			System.out.println("Enter Customer Email ");
			customer.setEmail(sc.next());
			System.out.println("Enter Customer PhoneNumber ");
			customer.setPhoneNumber(sc.next());
			
			CustomerDao dao = new CustomerDaoImpl();
			try {
				System.out.println(dao.addCustomerDao(customer));
				}
			 catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
