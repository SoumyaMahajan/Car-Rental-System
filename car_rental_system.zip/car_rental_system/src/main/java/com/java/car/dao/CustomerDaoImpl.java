package com.java.car.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.java.car.model.Customer;
import com.java.car.util.DBConnUtil;
import com.java.car.util.DBPropertyUtil;
import com.java.car.model.Customer;

public class CustomerDaoImpl implements CustomerDao{
	
	Connection connection;
	PreparedStatement pst;

	@Override
	public List<Customer> showCustomerDao() throws ClassNotFoundException, SQLException {
		String connStr =com.java.car.util.DBPropertyUtil.connectionString("db");
		connection = com.java.car.util.DBConnUtil.getConnection(connStr);
		String cmd = "select * from Customer";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		List<Customer> customerList = new ArrayList<Customer>();
		Customer customer = null;
		while(rs.next()) {
			customer = new Customer();
			customer.setCustomerID(rs.getInt("customerID"));
			customer.setFirstName(rs.getString("firstName"));
			customer.setLastName(rs.getString("lastName"));
			customer.setEmail(rs.getString("email"));
			customer.setPhoneNumber(rs.getString("phoneNumber"));
			customerList.add(customer);
		}
		return customerList;
	}

	@Override
	public Customer searchByCustomerID(int customerID) throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "select * from Customer where customerID = ?";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, customerID);
		ResultSet rs = pst.executeQuery();
		Customer customer = null;
		if(rs.next()) {
			customer = new Customer();
			customer.setCustomerID(rs.getInt("customerID"));
			customer.setFirstName(rs.getString("firstName"));
			customer.setLastName(rs.getString("lastName"));
			customer.setEmail(rs.getString("email"));
			customer.setPhoneNumber(rs.getString("phoneNumber"));
		}
		return customer;
	}

	@Override
	public String addCustomerDao(Customer customer) throws ClassNotFoundException, SQLException {
		String connStr =DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		String cmd = "Insert into Customer(customerID, firstName, lastName, email, phoneNumber) "
				+ " values(?,?,?,?,?)";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, customer.getCustomerID());
		pst.setString(2, customer.getFirstName());
		pst.setString(3, customer.getLastName());
		pst.setString(4, customer.getEmail());
		pst.setString(5, customer.getPhoneNumber());
		pst.executeUpdate();
		return "Customer Record Inserted...";
	}

	@Override
	public String updateCustomerDao(Customer customer) throws ClassNotFoundException, SQLException {
		Customer customerFound = searchByCustomerID(customer.getCustomerID());
		if (customerFound!=null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "Update Customer set firstName = ?, lastName = ?, email = ?, phoneNumber = ? where customerID = ?";
			pst = connection.prepareStatement(cmd);
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setString(3, customer.getEmail());
			pst.setString(4, customer.getPhoneNumber());
			pst.setInt(5, customer.getCustomerID());
			pst.executeUpdate();
			return "*** Customer Record Updated ***";
		}
		return "*** Customer Record Not Updated ***";
	}

	@Override
	public String deleteCustomerDao(int customerID) throws ClassNotFoundException, SQLException {
		Customer customerFound = searchByCustomerID(customerID);
		if (customerFound !=null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			String cmd = "Delete From Customer Where customerID = ?";
			pst = connection.prepareStatement(cmd);
			pst.setInt(1, customerID);
			pst.executeUpdate();
			return "*** Customer Record Deleted ***";
		}
		return "*** Customer Record Not Found ***";
	}

	       
}
