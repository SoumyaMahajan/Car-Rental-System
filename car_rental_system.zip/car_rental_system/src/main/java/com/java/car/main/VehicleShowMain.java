package com.java.car.main;

import java.sql.SQLException;
import java.util.List;

import com.java.car.dao.CustomerDao;
import com.java.car.dao.CustomerDaoImpl;
import com.java.car.dao.VehicleDao;
import com.java.car.dao.VehicleDaoImpl;
import com.java.car.model.Customer;
import com.java.car.model.Vehicle;

public class VehicleShowMain {

	 public static void main(String[] args) {
			VehicleDao dao = new VehicleDaoImpl();
			try {
				List<Vehicle> vehicleList = dao.showVehicleDao();
				for (Vehicle vehicle : vehicleList) {
					System.out.println(vehicle);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
}
