package com.java.car.model;

public class Payments {

	private int paymentID;
    private int leaseID;
    private int paymentDate;
    private double amount;
	public int getpaymentID() {
		return paymentID;
}
	public int getPaymentID() {
		return paymentID;
	}
	public void setPaymentID(int paymentID) {
		this.paymentID = paymentID;
	}
	public int getLeaseID() {
		return leaseID;
	}
	public void setLeaseID(int leaseID) {
		this.leaseID = leaseID;
	}
	public int getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(int paymentDate) {
		this.paymentDate = paymentDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Payments() {
	}
	public Payments(int paymentID, int leaseID, int paymentDate, double amount) {
		super();
		this.paymentID = paymentID;
		this.leaseID = leaseID;
		this.paymentDate = paymentDate;
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Payments [paymentID=" + paymentID + ", leaseID=" + leaseID + ", paymentDate=" + paymentDate
				+ ", amount=" + amount + "]";
	}
	
	
	
	
	
}
