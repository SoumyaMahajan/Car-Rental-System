package com.java.car.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.car.model.Lease;
import com.java.car.model.Vehicle;

public interface LeaseDao {

	List<Lease> showLeaseDao() throws ClassNotFoundException, SQLException;
	String addLeaseDao(Lease lease) throws ClassNotFoundException, SQLException;
}
