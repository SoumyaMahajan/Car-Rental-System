package com.java.car.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.car.model.Customer;

public interface CustomerDao {
           
	List<Customer> showCustomerDao() throws ClassNotFoundException, SQLException;
    Customer searchByCustomerID(int customerID) throws ClassNotFoundException, SQLException;
    String addCustomerDao(Customer customer) throws ClassNotFoundException, SQLException;
	   String updateCustomerDao(Customer customer) throws ClassNotFoundException, SQLException;
	   String deleteCustomerDao(int customerID) throws ClassNotFoundException, SQLException;
}
