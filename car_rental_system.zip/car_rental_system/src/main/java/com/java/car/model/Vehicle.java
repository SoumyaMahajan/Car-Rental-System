package com.java.car.model;

public class Vehicle {

	private int VehicleID;
	private String Make;
	private String Model;
	private int Year;
	private double DailyRate;
	private int Status;
	private int PassengerCapacity;
	private int EngineCapacity;
	public int getVehicleID() {
		return VehicleID;
	}
	public String getMake() {
		return Make;
	}
	public void setMake(String make) {
		Make = make;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public double getDailyRate() {
		return DailyRate;
	}
	public void setDailyRate(double dailyRate) {
		DailyRate = dailyRate;
	}
	public int getStatus() {
		return Status;
	}
	public void setStatus(int status) {
		Status = status;
	}
	public int getPassengerCapacity() {
		return PassengerCapacity;
	}
	public void setPassengerCapacity(int passengerCapacity) {
		PassengerCapacity = passengerCapacity;
	}
	public int getEngineCapacity() {
		return EngineCapacity;
	}
	public void setEngineCapacity(int engineCapacity) {
		EngineCapacity = engineCapacity;
	}
	public void setVehicleID(int vehicleID) {
		VehicleID = vehicleID;
	}
	public Vehicle() {
		
	}
	public Vehicle(int vehicleID, String make, String model, int year, double dailyRate, int status,
			int passengerCapacity, int engineCapacity) {
		VehicleID = vehicleID;
		Make = make;
		Model = model;
		Year = year;
		DailyRate = dailyRate;
		Status = status;
		PassengerCapacity = passengerCapacity;
		EngineCapacity = engineCapacity;
	}
	@Override
	public String toString() {
		return "Vehicle [VehicleID=" + VehicleID + ", Make=" + Make + ", Model=" + Model + ", Year="
				+ Year + ", DailyRate=" + DailyRate + ", Status=" + Status + ", PassengerCapacity=" + PassengerCapacity
				+ ", EngineCapacity=" + EngineCapacity + "]";
	}
	
	
	
	
}
